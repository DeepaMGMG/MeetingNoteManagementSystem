<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Signupcontroller extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$this->load->view('Signup_view');
	}

	public function insert_users() {

		$this->form_validation->set_rules('name', 'First Name', 'trim|required|alpha|min_length[3]|max_length[30]');
		$this->form_validation->set_rules('lastname', 'Last Name', 'trim|required|alpha|min_length[3]|max_length[30]');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('pass', 'Password', 'trim|required|md5');
		$this->form_validation->set_rules('confirmpass', 'Confirm Password','trim|required|md5');
		$this->form_validation->set_rules('role', 'Role', 'trim|required');
		$this->form_validation->set_rules('dept', 'Department', 'trim|required');

		// submit
		if ($this->form_validation->run() == FALSE)
		{     // fails
			$this->load->view('Signup_view');
			$this->session->set_flashdata('msg','<div class="alert alert-success text-center">Oops!error Occured</div>');
			$data['reset'] = FALSE;
		}
		else
		{
			$this->load->model('Adduser');
			$data = array(
				'firstname' => $this->input->post('username'),
				'lastname' => $this->input->post('lastname'),
				'email' => $this->input->post('email'),
				'password' => $this->input->post('pass'),
				'role' => $this->input->post('role'),
				'department' => $this->input->post('dept'),
				'employee_type'=>"1"
			);
			$this->Adduser->insert($data);
			$data['reset'] = TRUE;
			$this->session->set_flashdata('msg','<div class="alert alert-success text-center">User Added Successfully!</div>');
			redirect('Signupcontroller/index',"refresh");

		}

	}
}
