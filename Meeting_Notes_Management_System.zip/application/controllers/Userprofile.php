<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Userprofile extends CI_Controller {

  public function __construct()
  {
    parent::__construct();
    $this->load->helper('url');
    $this->load->model('Adduser');
  }

  public function index()
  {//This fuction is dropped and not used
    $data['Meeting_Notes']=$this->Adduser->get_all_notes();
    $data['My_Notes']=$this->Adduser->get_my_notes();

    $this->load->view('userprofile_view',$data);
  }

  public function addnotes()
  {
    //$this->load->view('newaddnotes');
    $data['employee']=$this->Adduser->get_all_employee();
    $data['employee1']=$this->Adduser->get_all_project_name();
    $this->load->view('addnotes',$data);
  }

  public function savenotes()
  {
    $attendies = $this->input->post('attendies');
    $attendiesArray = explode(',', $attendies);//by here i got all values

    $tags = $this->input->post('tags');
    $tagsArray = explode(',', $tags);//by here i got all values

    $notesdata = array(
      'Subject' => $this->input->post('subject'),
      'Project_Id' => $this->input->post('projects'),
      'Meeting_Date' => $this->input->post('date'),
      'Privilage' => $this->input->post('privilage'),
      'Meeting_Hours' => $this->input->post('hours'),
      'Documents' => $this->input->post('docs'),
      'Note_details' => $this->input->post('notes'),
      'Created_By' => $this->session->userdata('uid'),
      'Atendies' => serialize($attendies),
      'Tags' => serialize($tags)
    );
    $this->Adduser->insert_my_note($notesdata);
    $this->addnotes();//calling nested function
  }
  public function update_notes()
  {
    $notesdata = array(
      'Subject' => $this->input->post('Subject'),
      'Project_Id' => $this->input->post('projects'),
      'Meeting_Date' => $this->input->post('Meeting_Date'),
      'Privilage' => $this->input->post('privilage'),
      'Meeting_Hours' => $this->input->post('Meeting_Hours'),
      'Note_details' => $this->input->post('Note_details')
    );
    $this->Adduser->notes_update(array('M_Id' => $this->input->post('M_Id')), $notesdata);
    echo json_encode(array("status" => TRUE));

  }
}
