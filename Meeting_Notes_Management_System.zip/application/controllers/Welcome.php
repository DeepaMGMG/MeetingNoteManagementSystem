<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Adduser');//load required model
	}

	//default home page
	public function index()
	{
		$this->load->view('welcome_message');
	}
	//call login page
	public function login()
	{
		$this->load->view('Login_view');
	}

	//validate user login
	function validateuserlogin()
	{
		// get form input
		$email = $this->input->post("email");
		$password = $this->input->post("pass");

		// form validation
		$this->form_validation->set_rules("email", "email", "required");
		$this->form_validation->set_rules("pass", "password", "required");

		if ($this->form_validation->run() == FALSE)
		{
			$this->session->set_flashdata1('msg','<div class="alert alert-success text-center">Username or password is wrong</div>');
			redirect('Welcome/login',"refresh");
		}
		else
		{ // check for user credentials
			$uresult = $this->Adduser->check_user($email, $password);
			if (count($uresult) > 0)
			{
				$Userid=$uresult[0]->uid;
				$sess_data = array('login' => TRUE, 'uname' => $uresult[0]->firstname, 'uid' => $uresult[0]->uid,'usertype' => $uresult[0]->employee_type);
				$this->session->set_userdata($sess_data);
				$uresult['Meeting_All_Notes']=$this->Adduser->get_all_notes();//fetch all notes related to user
				$uresult['Meeting_My_Notes']=$this->Adduser->get_my_notes($Userid);//fetch only my notes
				$uresult['Employee_Details']=$this->Adduser->get_all_employee();//fetch employee details to list for admin
				$uresult['Project_Name']=$this->Adduser->get_all_project_name();//send project name
				$uresult['employee_Name']=$this->Adduser->get_all_employee();//send project name
				$this->load->view('userprofile_view',$uresult);// load profile page
			}
			else
			{
				$this->load->view('Login_view');
				$this->session->set_flashdata('msg', '<div class="alert alert-danger text-center">Wrong Email-ID or Password!</div>');
			}
		}
	}
	//on logout destroy all sessions

	function user_authenticated()
	{
		$Userid=$this->session->userdata('uid');
		$uresult['Meeting_All_Notes']=$this->Adduser->get_all_notes();//fetch all notes related to user
		$uresult['Meeting_My_Notes']=$this->Adduser->get_my_notes($Userid);//fetch only my notes
		$uresult['Employee_Details']=$this->Adduser->get_all_employee();//fetch employee details to list for admin
		$uresult['Project_Name']=$this->Adduser->get_all_project_name();//send project name
		$uresult['employee_Name']=$this->Adduser->get_all_employee();//send project name
		$this->load->view('userprofile_view',$uresult);// load profile page
	}

	function logout()
	{
		$this->session->sess_destroy();
		$this->load->view('welcome_message');
	}

	//Functions related to AJAX
	public function ajax_edit_notes($id)
	{
		$data = $this->Adduser->get_notes_by_id($id);
		echo json_encode($data);
	}

	public function ajax_notes_details($id)
	{
		$data1 = $this->Adduser->get_notes_by_id($id);
		echo json_encode($data1);
	}

}
