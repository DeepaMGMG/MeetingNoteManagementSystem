<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
  <title>Add Notes</title>
  <!-- Add to homescreen for Chrome on Android -->
  <meta name="mobile-web-app-capable" content="yes">
  <!-- Add to homescreen for Safari on iOS -->
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <meta name="apple-mobile-web-app-title" content="Material Design Lite">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.deep_purple-pink.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>styles.css">

  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  <link href="http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.0.3/css/bootstrap.min.css"
  rel="stylesheet" type="text/css" />
  <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.0.3/js/bootstrap.min.js"></script>
  <link href="http://cdn.rawgit.com/davidstutz/bootstrap-multiselect/master/dist/css/bootstrap-multiselect.css"
  rel="stylesheet" type="text/css" />
  <script src="http://cdn.rawgit.com/davidstutz/bootstrap-multiselect/master/dist/js/bootstrap-multiselect.js"
  type="text/javascript"></script>

  <!-- Include Date Range Picker -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

  <script type="text/javascript">
  $(function () {
    $('#attendies').multiselect({
      includeSelectAllOption: true
    });
  });
  $(document).ready(function(){
    var date_input=$('input[name="date"]'); //our date input has the name "date"
    var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
    date_input.datepicker({
      format: 'yyyy/mm/dd',
      container: container,
      todayHighlight: true,
      autoclose: true,
    })
  });

  function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
      alert("characters not allowed");
    }
    return true;
  }

  </script>

  <style type="text/css">
  .subject
  {
    background-color: #ffc8dc;
  }
  .note
  {
    background-color: white;
  }
  .text-danger {
    color: #a94442;
  }
  body{
    background-color: #ffc8dc;
  }
  </style>
</head>
<body >
  <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
    <header class="mdl-layout__header mdl-layout__header--scroll mdl-color--primary">
      <div class="mdl-layout--large-screen-only mdl-layout__header-row">
        <a href="<?php echo base_url(); ?>index.php/Welcome/user_authenticated" id="view-source" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--accent mdl-color-text--accent-contrast">Back</a>
        <h3>ADD MEETING NOTES</h3>
      </div>
    </header>
    <main class="mdl-layout__content">
      <div class="mdl-layout__tab-panel is-active " id="overview">
        <?php echo form_open('Userprofile/savenotes'); ?>
        <div class="mdl-grid">
          <div class="mdl-cell mdl-cell--4-col subject">
            <!-- i have input elements here -->
            <div class="row margin">
              <div class="input-field col s4">
                <label for="subject" class="center-align">Subject</label>
                <input id="subject" type="text" name="subject" value="<?php echo set_value('Subject'); ?>">
                <span class="text-danger"><?php echo form_error('subject'); ?></span>
              </div>
            </div>  <!--  my row ends here -->
            <br />

            <div class="row margin">
              <div class="input-field col s4">
                <label for="project" class="center-align">Project</label>
                <select id="project" name="projects" value="<?php echo set_value('Project_Name'); ?>">
                  <?php foreach($employee1 as $emp1){?>

                    <option value=<?php  echo $emp1->P_Id; ?>><?php  echo $emp1->Project_Name; ?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>  <!--  my row ends here -->
              <br />

              <div class="row margin">
                <div class="input-field col s4">
                  <label for="date" class="center-align">Meeting Date</label>
                  <input id="date" type="date" name="date" value="<?php echo set_value('Meeting_Date'); ?>">
                  <span class="text-danger"><?php echo form_error('date'); ?></span>
                </div>
              </div>  <!--  my row ends here -->
              <br />

              <div class="row margin">
                <label for="attendies" class="center-align">Attendies</label>
                <select id="attendies" multiple="multiple" name="attendies">
                  <?php foreach($employee as $emp){?>
                    <option value=<?php echo $emp->uid; ?> > <?php echo $emp->email; ?></option>
                    <?php } ?>
                  </select>
                </div>
                <br />

                <div class="row margin">
                  <label class="control-label col-md-3">Privilage</label>
                  <fieldset data-role="controlgroup">
                    <label for="private">Private</label>
                    <input type="radio" name="privilage" id="private" value="private">
                    <label for="public">Public</label>
                    <input type="radio" name="privilage" id="public" value="public">
                  </fieldset>
                  <span class="text-danger"><?php echo form_error('privilage'); ?></span>
                </div>  <!--  my row ends here -->
                <br />
                <div class="row margin">
                  <div class="input-field col s12">
                    <div class="input-field col s4">
                      <label for="hours" class="center-align">Hours Spent</label>
                      <select id="hours" name="hours" >
                        <?php $value=0;
                        for($i=0;$i<=29;$i++)
                        {
                          $value=$value+1; ?>
                          <option value=<?php echo $value; ?>><?php echo $value; ?></option>
                          <?php  } ?>
                        </select>

                        <span class="text-danger"><?php echo form_error('hours'); ?></span>
                      </div>
                    </div>
                  </div>  <!--  my row ends here -->
                  <br />
                  <div class="row margin">
                    <div class="input-field col s12">
                      <div class="input-field col s4">
                        <label for="docs" class="center-align">Attach Docs</label><br />
                        <input id="docs" type="file" name="docs"?>
                        <span class="text-danger"><?php echo form_error('docs'); ?></span>
                      </div>
                    </div>
                  </div>  <!--  my row ends here -->
                  <br />

                  <div class="input-field col s4">
                    <div class="demo">
                      <div class="control-group">
                        <label for="input-tags">Tags:</label>
                        <input type="text" id="input-tags" class="demo-default" name="tags" value="<?php echo set_value('Tags'); ?>" >
                      </div>
                      <script>
                      $('#input-tags').selectize({
                        persist: false,
                        createOnBlur: true,
                        create: true
                      });
                      </script>
                    </div>
                  </div>
                  <!--  my row ends here -->
                </div><!-- My input element section ends here -->

                <div class="mdl-cell mdl-cell--7-col note">
                  <!-- i have long notes here -->
                  <textarea class="mdl-textfield__input" name="notes" type="text" rows= "20"  id="sample5" placeholder="Add notes here..."
                  value="<?php echo set_value('Note_details'); ?>"></textarea>
                  <br />
                  <input type="submit" name="submit" value="Submit" />
                </div>
              </div>
              <?php echo form_close(); ?>
            </div>
          </main>
        </div>

      </body>
      </html>
