<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!doctype html>

<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
  <title>Home</title>

  <!-- Add to homescreen for Chrome on Android -->
  <meta name="mobile-web-app-capable" content="yes">
  <link rel="icon" sizes="192x192" href="images/android-desktop.png">

  <!-- Add to homescreen for Safari on iOS -->
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <meta name="apple-mobile-web-app-title" content="Material Design Lite">
  <link rel="apple-touch-icon-precomposed" href="images/ios-desktop.png">

  <!-- Tile icon for Win8 (144x144 + tile color) -->
  <meta name="msapplication-TileImage" content="images/touch/ms-touch-icon-144x144-precomposed.png">
  <meta name="msapplication-TileColor" content="#3372DF">

  <link rel="shortcut icon" href="images/favicon.png">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.deep_purple-pink.min.css">

  <style>
  html, body {
    font-family: 'Roboto', 'Helvetica', sans-serif;
    margin: 0;
    padding: 0;
  }
  .mdl-demo .mdl-layout__header-row {
    padding-left: 40px;
  }
  .mdl-demo .mdl-layout.is-small-screen .mdl-layout__header-row h3 {
    font-size: inherit;
  }

  .mdl-demo .mdl-layout__header-row .a {
    color:#000000;
  }
  .mdl-demo .mdl-layout.is-small-screen .mdl-layout__header-row .a {
    color:#000000;
  }

  .mdl-demo .mdl-card {
    height: auto;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
  }
  .mdl-demo .mdl-card > * {
    height: auto;
  }
  .mdl-demo .mdl-card .mdl-card__supporting-text {
    margin: 40px;
    -webkit-flex-grow: 1;
    -ms-flex-positive: 1;
    flex-grow: 1;
    padding: 0;
    color: inherit;
    width: calc(100% - 80px);
  }
  .mdl-demo.mdl-demo .mdl-card__supporting-text h4 {
    margin-top: 0;
    margin-bottom: 20px;
  }
  .mdl-demo .mdl-card__actions {
    margin: 0;
    padding: 4px 40px;
    color: inherit;
  }
  .mdl-demo .mdl-card__actions a {
    color: #00BCD4;
    margin: 0;
  }
  .mdl-demo .mdl-card__actions a:hover,
  .mdl-demo .mdl-card__actions a:active {
    color: inherit;
    background-color: transparent;
  }
  .mdl-demo .mdl-card__supporting-text + .mdl-card__actions {
    border-top: 1px solid rgba(0, 0, 0, 0.12);
  }
  .mdl-demo #add {
    position: absolute;
    right: 40px;
    top: 36px;
    z-index: 999;
  }

  .mdl-demo .mdl-layout__content section:not(:last-of-type) {
    position: relative;
    margin-bottom: 48px;
  }
  .mdl-demo section.section--center {
    max-width: 860px;
  }
  .mdl-demo #features section.section--center {
    max-width: 620px;
  }
  .mdl-demo section > header{
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-justify-content: center;
    -ms-flex-pack: center;
    justify-content: center;
  }
  .mdl-demo section > .section__play-btn {
    min-height: 200px;
  }
  .mdl-demo section > header > .material-icons {
    font-size: 3rem;
  }
  .mdl-demo section > button {
    position: absolute;
    z-index: 99;
    top: 8px;
    right: 8px;
  }
  .mdl-demo section .section__circle {
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-align-items: center;
    -ms-flex-align: center;
    align-items: center;
    -webkit-justify-content: flex-start;
    -ms-flex-pack: start;
    justify-content: flex-start;
    -webkit-flex-grow: 0;
    -ms-flex-positive: 0;
    flex-grow: 0;
    -webkit-flex-shrink: 1;
    -ms-flex-negative: 1;
    flex-shrink: 1;
  }
  .mdl-demo section .section__text {
    -webkit-flex-grow: 1;
    -ms-flex-positive: 1;
    flex-grow: 1;
    -webkit-flex-shrink: 0;
    -ms-flex-negative: 0;
    flex-shrink: 0;
    padding-top: 8px;
  }
  .mdl-demo section .section__text h5 {
    font-size: inherit;
    margin: 0;
    margin-bottom: 0.5em;
  }
  .mdl-demo section .section__text a {
    text-decoration: none;
  }
  .mdl-demo section .section__circle-container > .section__circle-container__circle {
    width: 64px;
    height: 64px;
    border-radius: 32px;
    margin: 8px 0;
  }
  .mdl-demo section.section--footer .section__circle--big {
    width: 100px;
    height: 100px;
    border-radius: 50px;
    margin: 8px 32px;
  }
  .mdl-demo .is-small-screen section.section--footer .section__circle--big {
    width: 50px;
    height: 50px;
    border-radius: 25px;
    margin: 8px 16px;
  }
  .mdl-demo section.section--footer {
    padding: 64px 0;
    margin: 0 -8px -8px -8px;
  }
  .mdl-demo section.section--center .section__text:not(:last-child) {
    border-bottom: 1px solid rgba(0,0,0,.13);
  }
  .mdl-demo .mdl-card .mdl-card__supporting-text > h3:first-child {
    margin-bottom: 24px;
  }
  .mdl-demo .mdl-layout__tab-panel:not(#overview) {
    background-color: white;
  }
  .mdl-demo #features section {
    margin-bottom: 72px;
  }

  .mdl-demo .toc {
    border-left: 4px solid #C1EEF4;
    margin: 24px;
    padding: 0;
    padding-left: 8px;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-direction: column;
    -ms-flex-direction: column;
    flex-direction: column;
  }
  .mdl-demo .toc h4 {
    font-size: 0.9rem;
    margin-top: 0;
  }

  a {
    color: #ffffff;
  }

  </style>
</head>
<body class="mdl-demo mdl-color--grey-100 mdl-color-text--grey-700 mdl-base">
  <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
    <header class="mdl-layout__header mdl-layout__header--scroll mdl-color--primary">
      <div class="mdl-layout--large-screen-only mdl-layout__header-row">
      </div>
      <div class="mdl-layout--large-screen-only mdl-layout__header-row">
        <h3>MEETING NOTES MANAGEMENT</h3>
      </div>
      <div class="mdl-layout--large-screen-only mdl-layout__header-row">
        <a href = "<?php echo base_url(); ?>index.php/Welcome/login">LOGIN</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      </div>
    </header>
    <main class="mdl-layout__content">
      <div class="mdl-layout__tab-panel is-active" id="overview">
        <section class="section--center mdl-grid mdl-grid--no-spacing mdl-shadow--2dp">
          <div class="mdl-card mdl-cell mdl-cell--12-col">
            <div class="mdl-card__supporting-text mdl-grid mdl-grid--no-spacing">
              <h4 class="mdl-cell mdl-cell--12-col">Features</h4>
              <div class="section__circle-container mdl-cell mdl-cell--2-col mdl-cell--1-col-phone">
                <div class="section__circle-container__circle mdl-color--primary"></div>
              </div>
              <div class="section__text mdl-cell mdl-cell--10-col-desktop mdl-cell--6-col-tablet mdl-cell--3-col-phone">
                <h5>Add Meeting Notes</h5>
                Manages Meeting Notes,Documents by meeting attendies from different project in an organization.
              </div>
              <div class="section__circle-container mdl-cell mdl-cell--2-col mdl-cell--1-col-phone">
                <div class="section__circle-container__circle mdl-color--primary"></div>
              </div>
              <div class="section__text mdl-cell mdl-cell--10-col-desktop mdl-cell--6-col-tablet mdl-cell--3-col-phone">
                <h5>List Notes</h5>
                List the Notes based on privilages.Also have feature to filter the meeting notes based on some attributes.
              </div>
              <div class="section__circle-container mdl-cell mdl-cell--2-col mdl-cell--1-col-phone">
                <div class="section__circle-container__circle mdl-color--primary"></div>
              </div>
              <div class="section__text mdl-cell mdl-cell--10-col-desktop mdl-cell--6-col-tablet mdl-cell--3-col-phone">
                <h5>Report</h5>
                It have ability to download attached documents,Ability to filter by tags,Commenting feature for notes
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>

  </main>
</div>
<script src="https://code.getmdl.io/1.3.0/material.min.js"></script>

</body>
</html>
