<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Add User</title>
  <!-- CORE CSS-->

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/css/materialize.min.css">

  <style type="text/css">
  html,
  body {
    height: 100%;
  }
  html {
    display: table;
    margin: auto;
  }
  body {
    display: table-cell;
    vertical-align: middle;
  }
  .margin {
    margin: 0 !important;
  }

  .text-danger {
    color: #a94442;
  }
  </style>

</head>

<body class="blue">
  <br />
<br />
  <div id="login-page" class="row">
    <div class="col s12 z-depth-6 card-panel">
<h5>ADD USER</h5>
      <?php echo form_open('Signupcontroller/insert_users'); ?>
      <div class="row margin">
        <div class="input-field col s6">
          <i class="mdi-social-person-outline prefix"></i>
          <input id="username" type="text" name="username" value="<?php echo set_value('firstname'); ?>">
          <label for="username" class="center-align">First Name</label>
          <span class="text-danger"><?php echo form_error('name'); ?></span>
        </div>

        <div class="input-field col s6">
          <i class="mdi-av-recent-actors prefix"></i>
          <input id="lastname" type="text" name="lastname" value="<?php echo set_value('lastname'); ?>">
          <label for="lastname" class="center-align">Last Name</label>
          <span class="text-danger"><?php echo form_error('lastname'); ?></span>
        </div>
      </div>

      <div class="row margin">
        <div class="input-field col s6">
          <i class="mdi-action-lock-outline prefix"></i>
          <input id="password" type="password" name="pass" value="<?php echo set_value('password'); ?>">
          <label for="password">Password</label>
          <span class="text-danger"><?php echo form_error('pass'); ?></span>
        </div>

        <div class="input-field col s6">
          <i class="mdi-alert-error prefix"></i>
          <input id="password-again" type="password" name="confirmpass" value="<?php echo set_value('user_name'); ?>">
          <label for="password-again">Confirm Password</label>
          <span class="text-danger"><?php echo form_error('confirmpass'); ?></span>
        </div>
      </div>
      <div class="row margin">
        <div class="input-field col s12">
          <i class="mdi-communication-email prefix"></i>
          <input id="email" type="email" name="email" value="<?php echo set_value('email'); ?>">
          <label for="email" class="center-align">Email</label>
          <span class="text-danger"><?php echo form_error('email'); ?></span>
        </div>
      </div>
      <div class="row margin">
        <div class="input-field col s6">
          <i class="mdi-action-work prefix"></i>
          <input id="role" type="text" name="role" value="<?php echo set_value('role'); ?>">
          <label for="role">Role</label>
          <span class="text-danger"><?php echo form_error('role'); ?></span>
        </div>

        <div class="input-field col s6">
          <i class="mdi-action-list prefix"></i>
          <input id="dept" type="text" name="dept" value="<?php echo set_value('department'); ?>">
          <label for="dept" class="center-align">Department</label>
          <span class="text-danger"><?php echo form_error('dept'); ?></span>
        </div>
      </div>
      <br />
      <input type="submit" name="submit" value="Submit" />
      <?php echo form_close(); ?>
      <?php echo $this->session->flashdata('msg'); ?>
    </div>
    <button class="btn btn-warning" onclick="location.href='<?php echo base_url() ?>index.php/Welcome/user_authenticated'" >DONE!TAKE ME TO PROFILE</button>
  </div>
  <!-- jQuery Library -->
  <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <!--materialize js-->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/js/materialize.min.js"></script>
</body>

</html>
