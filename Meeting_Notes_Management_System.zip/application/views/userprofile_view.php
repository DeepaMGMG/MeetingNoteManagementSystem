<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>

<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="A front-end template that helps you build fast, modern mobile web apps.">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
  <title>User Profile</title>

  <!-- links to use bootstrap table and elements -->
  <link href="http://localhost/CI/demo/assests/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="http://localhost/CI/demo/assests/datatables/css/dataTables.bootstrap.css" rel="stylesheet">
  <script src="http://localhost/CI/demo/assests/jquery/jquery-3.1.0.min.js"></script>
  <script src="http://localhost/CI/demo/assests/bootstrap/js/bootstrap.min.js"></script>
  <script src="http://localhost/CI/demo/assests/datatables/js/jquery.dataTables.min.js"></script>
  <script src="http://localhost/CI/demo/assests/datatables/js/dataTables.bootstrap.js"></script>

  <!-- Add to homescreen for Chrome on Android -->
  <meta name="mobile-web-app-capable" content="yes">
  <link rel="icon" sizes="192x192" href="images/android-desktop.png">

  <!-- Add to homescreen for Safari on iOS -->
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black">
  <meta name="apple-mobile-web-app-title" content="Material Design Lite">
  <link rel="apple-touch-icon-precomposed" href="images/ios-desktop.png">
  <!-- w3school for stripped table -->
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <!-- Tile icon for Win8 (144x144 + tile color) -->
  <meta name="msapplication-TileImage" content="images/touch/ms-touch-icon-144x144-precomposed.png">
  <meta name="msapplication-TileColor" content="#3372DF">

  <link rel="canonical" href="http://www.example.com/">


  <!-- Include Date Range Picker -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

  <script type="text/javascript">
  $(function () {
    $('#attendies').multiselect({
      includeSelectAllOption: true
    });
  });
  $(document).ready(function(){
    var date_input=$('input[name="Meeting_Date"]'); //our date input has the name "date"
    var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
    date_input.datepicker({
      format: 'yyyy/mm/dd',
      container: container,
      todayHighlight: true,
      autoclose: true,
    })
  })

  </script>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;lang=en">
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.deep_purple-pink.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>styles.css">
  <style>
  #view-source {
    position: fixed;
    display: block;
    right: 0;
    bottom: 0;
    margin-right: 40px;
    margin-bottom: 40px;
    z-index: 900;
  }
  </style>
</head>
<body class="mdl-demo mdl-color--grey-100 mdl-color-text--grey-700 mdl-base">
  <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
    <header class="mdl-layout__header mdl-layout__header--scroll mdl-color--primary">
      <div class="mdl-layout--large-screen-only mdl-layout__header-row">
      </div>
      <div class="mdl-layout--large-screen-only mdl-layout__header-row">
        <h3>MEETING NOTE MANAGEMENT SYSTEM</h3>
      </div>
      <div class="mdl-layout--large-screen-only mdl-layout__header-row">
      </div>
      <div class="mdl-layout__tab-bar mdl-js-ripple-effect mdl-color--primary-dark">
        <a href="#allnotes" class="mdl-layout__tab is-active">Meeting Notes</a>
        <a href="#mynotes" class="mdl-layout__tab">My Notes</a>
        <a href="#report" class="mdl-layout__tab">Report</a>
        <?php $usertype=$this->session->userdata('usertype');
        if($usertype==2)
        { ?>
          <a href="#admin" class="mdl-layout__tab">Users</a>
          <?php  } ?>
          <a href="<?php echo base_url(); ?>index.php/Userprofile/addnotes" class="mdl-button mdl-js-button mdl-button--fab mdl-js-ripple-effect mdl-button--colored mdl-shadow--4dp mdl-color--accent" id="add"> <i class="material-icons" role="presentation">add</i></a>

        </div>
      </header>
      <main class="mdl-layout__content">

        <!-- start listing all notes -->
        <div class="mdl-layout__tab-panel is-active" id="allnotes">
          <!-- display the notes in list -->
          <div class="container">
            <h3>MEETING NOTES</h3>
          </center>
          <br />

          <table id="alltable_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
              <tr>
                <th>MEETING ID</th>
                <th>SUBJECT</th>
                <th>PROJECT NAME</th>
                <th>MEETING DATE</th>
                <th>CREATED BY</th>
                <th>VIEW</th>
                <?php $usertype=$this->session->userdata('usertype');
                if($usertype==2)
                { ?>
                  <th style="width:125px;">Action
                  </p></th>
                  <?php  } ?>
                </tr>
              </thead>
              <tbody>
                <?php foreach($Meeting_All_Notes as $allnotes){?>
                  <tr>
                    <td><?php echo $allnotes->M_Id;?></td>
                    <td><?php echo $allnotes->Subject;?></td>
                    <td><?php echo $allnotes->projectname?></td>
                    <td><?php echo $allnotes->Meeting_Date;?></td>
                    <td><?php echo $allnotes->firstname;?></td>
                    <td>
                      <button class="btn btn-primary" onclick="view_notes(<?php echo $allnotes->M_Id;?>)"><i class="glyphicon glyphicon-eye-open"></i></button>
                    </td>
                    <?php $usertype=$this->session->userdata('usertype');
                    if($usertype==2)
                    { ?>
                      <td>
                        <button class="btn btn-primary" onclick="edit_notes_by_manager(<?php echo $allnotes->M_Id;?>)"><i class="glyphicon glyphicon-circle-arrow-right"></i></button>
                      </td>
                      <?php  } ?>

                    </tr>
                    <?php }?>
                  </tbody>
                </table>
              </div>
            </div>
            <!-- end of listing all meeting notes -->

            <!-- start of listing MY NOTES -->
            <div class="mdl-layout__tab-panel" id="mynotes">
              <div class="container">
                <h3>MY NOTES</h3>
              </center>
              <br />

              <table id="table_id_my_notes" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th>MEETING ID</th>
                    <th>SUBJECT</th>
                    <th>PROJECT NAME</th>
                    <th>MEETING DATE</th>
                    <th>CREATED BY</th>
                    <th style="width:125px;">Action
                    </p></th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach($Meeting_My_Notes as $mynotes){?>
                    <tr>
                      <td><?php echo $mynotes->M_Id;?></td>
                      <td><?php echo $mynotes->Subject;?></td>
                      <td><?php echo $mynotes->projectname?></td>
                      <td><?php echo $mynotes->Meeting_Date;?></td>
                      <td><?php echo $mynotes->firstname;?></td>
                      <td>
                        <button class="btn btn-primary" onclick="edit_note(<?php echo $mynotes->M_Id;?>)"><i class="glyphicon glyphicon-circle-arrow-right"></i></button>
                      </td>
                    </tr>
                    <?php }?>
                  </tbody>
                </table>
              </div>
            </div>
            <!-- this is my report -->
            <div class="mdl-layout__tab-panel" id="report">
              <h1>THIS IS REPORT</h1>
            </div>

            <!-- this is only for admin -->
            <div class="mdl-layout__tab-panel" id="admin">
              <h2>EMPLOYEE DETAILS</h2>
              <br />
              <button class="btn btn-success" onclick="location.href='<?php echo base_url() ?>index.php/Signupcontroller/index'" >ADD USER</button>
              <br /><br />
              <table class="w3-table-all">
                <thead>
                  <tr>
                    <th>User Id</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Department</th>
                    <th>employee_type</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach($Employee_Details as $employee){?>
                    <tr>
                      <td><?php echo $employee->uid;?></td>
                      <td><?php echo $employee->firstname;?></td>
                      <td><?php echo $employee->lastname;?></td>
                      <td><?php echo $employee->email;?></td>
                      <td><?php echo $employee->role;?></td>
                      <td><?php echo $employee->department;?></td>
                      <td><?php echo $employee->employee_type;?></td>

                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
              </div>
            </main>
          </div>

          <!-- Bootstrap modal -->
          <div class="modal fade" id="modal_form" role="dialog">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <h3 class="modal-title">Edit Notes</h3>
                </div>
                <div class="modal-body form">
                  <form action="#" id="form" class="form-horizontal">
                    <input type="hidden" value="" name="M_Id"/>
                    <div class="form-body">
                      <div class="form-group">
                        <label class="control-label col-md-3">Subject</label>
                        <div class="col-md-9">
                          <input name="Subject" placeholder="Book ISBN" class="form-control" type="text">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3">Project Name</label>
                        <div class="col-md-9">
                          <select id="Project_Id" name="projects" value="<?php echo set_value('Project_Id'); ?>">
                            <?php foreach($Project_Name as $pro){?>
                              <option value=<?php  echo $pro->P_Id; ?>><?php  echo $pro->Project_Name; ?></option>
                              <?php } ?>
                            </select>
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="control-label col-md-3">Meeting Date</label>
                          <div class="col-md-9">
                            <input name="Meeting_Date" placeholder="Book Category" class="form-control" type="text">
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="control-label col-md-3">Privilage</label>
                          <fieldset data-role="controlgroup">
                            <label for="private">Private</label>
                            <input type="radio" name="privilage" id="private" value="private">
                            <label for="public">Public</label>
                            <input type="radio" name="privilage" id="public" value="public" checked="checked">
                          </fieldset>
                        </div>

                        <!-- <div class="form-group">
                        <label class="control-label col-md-3">Attendies</label>
                        <div class="col-md-9">
                        <select id="attendies" multiple="multiple" name="attendies">
                        <?php foreach($employee_Name as $emp){?>
                        <option value=<?php echo $emp->uid; ?> > <?php echo $emp->email; ?></option>
                        <?php } ?>
                      </select>
                    </div>
                  </div> -->

                  <div class="form-group">
                    <label class="control-label col-md-3">Meeting Hours</label>
                    <div class="col-md-9">
                      <input name="Meeting_Hours" placeholder="Meeting Hours" class="form-control" type="text">
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="control-label col-md-3">Notes</label>
                    <div class="col-md-9">
                      <!-- <input name="Note_details" placeholder="Notes" class="form-control" type="text"> -->
                      <textarea class="mdl-textfield__input" name="Note_details" type="text" rows= "5"  id="sample5" placeholder="Add notes here..."
                      value="<?php echo set_value('Note_details'); ?>"></textarea>
                    </div>
                  </div>

                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button type="button" id="btnSave" onclick="save()" class="btn btn-primary">Save</button>
              <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
            </div>
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->
      <!-- End Bootstrap modal -->

      <div class="modal fade" id="modal_show" role="dialog">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <h3 class="modal-title">Notes</h3>
            </div>
            <!-- STARTS -->

            <section class="section--center mdl-grid mdl-grid--no-spacing mdl-shadow--2dp">
              <div class="mdl-card mdl-cell mdl-cell--12-col">
                <div class="mdl-card__supporting-text mdl-grid mdl-grid--no-spacing">
                  <div class="section__text mdl-cell mdl-cell--10-col-desktop mdl-cell--6-col-tablet mdl-cell--3-col-phone">
                    <h5>Subject</h5>
                    <div class="SubjectName"></div>
                  </div>

                  <div class="section__text mdl-cell mdl-cell--10-col-desktop mdl-cell--6-col-tablet mdl-cell--3-col-phone">
                    <h5>Project Name</h5>
                    <div class="ProjectName"></div>
                  </div>

                  <div class="section__text mdl-cell mdl-cell--10-col-desktop mdl-cell--6-col-tablet mdl-cell--3-col-phone">
                    <h5>Meeting Date</h5>
                    <div class="MeetingDate"></div>
                  </div>

                  <div class="section__text mdl-cell mdl-cell--10-col-desktop mdl-cell--6-col-tablet mdl-cell--3-col-phone">
                    <h5>Tags</h5>
                    <div class="Tags"></div>
                  </div>

                  <div class="section__text mdl-cell mdl-cell--10-col-desktop mdl-cell--6-col-tablet mdl-cell--3-col-phone">
                    <h5>Atendies</h5>
                    <div class="Attendencies"></div>
                  </div>

                  <div class="section__text mdl-cell mdl-cell--10-col-desktop mdl-cell--6-col-tablet mdl-cell--3-col-phone">
                    <h5>Spent Hours</h5>
                    <div class="Hours"></div>
                  </div>

                  <div class="section__text mdl-cell mdl-cell--10-col-desktop mdl-cell--6-col-tablet mdl-cell--3-col-phone">
                    <h5>Created By</h5>
                    <div class="Creater"></div>
                  </div>

                  <div class="section__text mdl-cell mdl-cell--10-col-desktop mdl-cell--6-col-tablet mdl-cell--3-col-phone">
                    <h5>Add Meeting Notes</h5>
                    <div class="Notes"></div>
                  </div>
                </div>
              </div>
            </section>
            <!-- ENDS -->
          </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
      </div><!-- /.modal -->
      <script src="https://code.getmdl.io/1.3.0/material.min.js"></script>

      <script type="text/javascript">
      $(document).ready( function () {
        $('#table_id').DataTable();

      } );

      var save_method; //for save method string
      var table;


      function edit_notes_by_manager(id)
      {
        save_method = 'update';
        $('#form')[0].reset(); // reset form on modals

        //Ajax Load data from ajax
        <!-- End Bootstrap modal -->

        href="<?php echo base_url(); ?>styles.css"
        $.ajax({
          url : "<?php echo base_url('index.php/Welcome/ajax_edit_notes/')?>/" + id,
          type: "POST",
          dataType: "JSON",
          success: function(data)
          {
            $('[name="M_Id"]').val(data.M_Id);
            $('[name="Subject"]').val(data.Subject);
            $('[name="Project_Id"]').val(data.Project_Id);
            $('[name="Note_details"]').val(data.Note_details);
            $('[name="Meeting_Date"]').val(data.Meeting_Date);
            $('[name="Privilage"]').val(data.Privilage);
            $('[name="Meeting_Hours"]').val(data.Meeting_Hours);
            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit Book'); // Set title to Bootstrap modal title
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
            alert('Error get data from ajax');
          }
        });
      }

      function view_notes(id)
      {
        save_method = 'update';
        $('#form')[0].reset(); // reset form on modals

        //Ajax Load data from ajax
        $.ajax({
          url : "<?php echo base_url('index.php/Welcome/ajax_notes_details/')?>/" + id,
          type: "POST",
          dataType: "JSON",
          success: function(data1)
          {
            $('.SubjectName').text(data1.Subject);
            $('.ProjectName').text(data1.projectname);
            $('.MeetingDate').text(data1.Meeting_Date);
            $('.Attendencies').text(data1.Atendies);
            $('.Hours').text(data1.Meeting_Hours);
            $('.Creater').text(data1.firstname);
            $('.Tags').text(data1.Tags);
            $('.Notes').text(data1.Note_details);

            $('#modal_show').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Notes Detail'); // Set title to Bootstrap modal title

          },
          error: function (jqXHR, textStatus, errorThrown)
          {
            alert('Error get data from ajax');
          }
        });
      }

      function save()
      {
        var url;
        url = "<?php echo base_url('index.php/Userprofile/update_notes')?>";
        // ajax adding data to database
        $.ajax({
          url : url,
          type: "POST",
          data: $('#form').serialize(),
          dataType: "JSON",
          success: function(data)
          {
            //if success close modal and reload ajax table
            $('#modal_form').modal('hide');
            location.reload();// for reload a page
          },
          error: function (jqXHR, textStatus, errorThrown)
          {
            alert('Error update data');
          }
        });
      }

      function delete_book(id)
      {
        if(confirm('Are you sure delete this data?'))
        {
          // ajax delete data from database
          $.ajax({
            url : "<?php echo base_url('index.php/book/book_delete')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {

              location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
              alert('Error deleting data');
            }
          });

        }
      }
      </script>
      <a href="<?php echo base_url('index.php/Welcome/logout')?>"  id="view-source" class="mdl-button mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--accent mdl-color-text--accent-contrast">Logout</a>
    </body>
    </html>
