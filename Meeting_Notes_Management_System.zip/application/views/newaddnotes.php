<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Learn PHP CodeIgniter Framework with AJAX and Bootstrap</title>
  <link href="http://localhost/CI/demo/assests/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="http://localhost/CI/demo/assests/datatables/css/dataTables.bootstrap.css" rel="stylesheet">
  <script src="http://localhost/CI/demo/assests/jquery/jquery-3.1.0.min.js"></script>
  <script src="http://localhost/CI/demo/assests/bootstrap/js/bootstrap.min.js"></script>
  <script src="http://localhost/CI/demo/assests/datatables/js/jquery.dataTables.min.js"></script>
  <script src="http://localhost/CI/demo/assests/datatables/js/dataTables.bootstrap.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

  <script type="text/javascript">
  $(function () {
    $('#attendies').multiselect({
      includeSelectAllOption: true
    });
  });
  $(document).ready(function(){
    var date_input=$('input[name="date"]'); //our date input has the name "date"
    var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
    date_input.datepicker({
      format: 'yyyy/mm/dd',
      container: container,
      todayHighlight: true,
      autoclose: true,
    })
  });

  function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
      alert("characters not allowed");
    }
    return true;
  }

  </script>

</head>
<body>
  <button class="btn btn-success" onclick="add_mynotes()"><i class="material-icons">add</i> Add keyword</button>
  <script type="text/javascript">
  $(document).ready( function () {
    $('#table_id').DataTable();
  } );
  var save_method; //for save method string
  var table;


  function add_mynotes()
  {
    save_method = 'add';
    $('#form')[0].reset(); // reset form on modals
    $('#modal_add_notes').modal('show'); // show bootstrap modal
    //$('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
  }


  function savemynotes()
  {
    var url;
    if(save_method == 'add')
    {
      url = "<?php echo base_url('index.php/Userprofile/savenotes')?>";
    }
    // ajax adding data to database
    $.ajax({
      url : url,
      type: "POST",
      data: $('#form').serialize(),
      dataType: "JSON",
      success: function(data)
      {
        //if success close modal and reload ajax table
        $('#modal_add_notes').modal('hide');
        location.reload();// for reload a page
      },
      error: function (jqXHR, textStatus, errorThrown)
      {
        alert('Error adding / update data');
      }
    });
  }

  </script>
  <!-- Bootstrap modal -->
  <div class="modal fade" id="modal_add_notes" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h3 class="modal-title">Book Form</h3>
        </div>
        <div class="modal-body form">
          <form action="#" id="form" class="form-horizontal">
            <input type="hidden" value="" name="book_id"/>
            <div class="form-body">
              <div class="form-group">
                <label class="control-label col-md-3">subject</label>
                <div class="col-md-9">
                  <input name="book_isbn" placeholder="Book ISBN" class="form-control" type="text">
                  <input id="subject" type="text" name="subject" >
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3">Project</label>
                <div class="col-md-9">
                  <select id="project" name="projects" >
                    <?php foreach($employee1 as $emp1){?>

                      <option value=<?php  echo $emp1->P_Id; ?>><?php  echo $emp1->Project_Name; ?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-md-3">Meeting Date</label>
                  <div class="col-md-9">
                    <input id="date" type="date" name="date" >
                  </div>
                </div>

                <div class="form-group">
                  <label class="control-label col-md-3">Attendies</label>
                  <div class="col-md-9">
                    <select id="attendies" multiple="multiple" name="attendies">
                      <?php foreach($employee as $emp){?>
                        <option value=<?php echo $emp->uid; ?> > <?php echo $emp->email; ?></option>
                        <?php } ?>
                      </select>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="control-label col-md-3">Meeting Date</label>
                    <div class="col-md-9">
                      <fieldset data-role="controlgroup">
                        <label for="private">Private</label>
                        <input type="radio" name="privilage" id="private" value="private">
                        <label for="public">Public</label>
                        <input type="radio" name="privilage" id="public" value="public">
                      </fieldset>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="control-label col-md-3">Hours Spent</label>
                    <div class="col-md-9">
                      <select id="hours" name="hours" >
                        <?php $value=0;
                        for($i=0;$i<=29;$i++)
                        {
                          $value=$value+1; ?>
                          <option value=<?php echo $value; ?>><?php echo $value; ?></option>
                          <?php  } ?>
                        </select>
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3">Document</label>
                      <div class="col-md-9">
                        <input id="docs" type="file" name="docs"?>
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3">Tags</label>
                      <div class="col-md-9">
                        <input type="text" id="input-tags" class="demo-default" name="tags">
                      </div>
                    </div>

                    <div class="form-group">
                      <label class="control-label col-md-3">Tags</label>
                      <div class="col-md-9">
                        <textarea class="mdl-textfield__input" name="notes" type="text" rows= "10"  id="sample5" placeholder="Add notes here..."></textarea>
                      </div>
                    </div>

                  </div>
                </form>
              </div>
              <div class="modal-footer">
                <button type="button" id="btnSave" onclick="savemynotes()" class="btn btn-primary">Save</button>
                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
              </div>
            </div><!-- /.modal-content -->
          </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
        <!-- End Bootstrap modal -->

      </body>
      </html>
