<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Registration</title>
  <!-- CORE CSS-->

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/css/materialize.min.css">

  <style type="text/css">
  html,
  body {
    height: 100%;
  }
  html {
    display: table;
    margin: auto;
  }
  body {
    display: table-cell;
    vertical-align: middle;
  }
  .margin {
    margin: 0 !important;
  }
  </style>

</head>

<body class="blue">


  <div id="login-page" class="row">
    <div class="col s12 z-depth-6 card-panel">
      <?php echo form_open('Welcome/validateuserlogin'); ?>

      <div class="row margin">
        <div class="input-field col s12">
          <i class="mdi-communication-email prefix"></i>
          <input id="email" type="email" name="email">
          <label for="email" class="center-align">Email</label>
        </div>
      </div>

      <div class="row margin">
        <div class="input-field col s12">
          <i class="mdi-action-lock-outline prefix"></i>
          <input id="password" type="password" name="pass" >
          <label for="password">Password</label>
        </div>
      </div>

      <br />
      <input type="submit" name="submit" value="Submit" />
    </div>
    <?php echo form_close(); ?>
      <?php echo $this->session->flashdata1('msg'); ?>
  </div>
</div>
<!-- jQuery Library -->
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<!--materialize js-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.1/js/materialize.min.js"></script>
</body>

</html>
