<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//this is mom adduser model

class Adduser extends CI_Model {
  //default constuctor
  function __construct() {
    parent::__construct();
  }
  //function to insert form data into user table
  public function insert($data)
  {
    if ($this->db->insert("employee", $data))
    {
      return true;
    }
  }

  //fetch user from employee table to validate login
  function check_user($email, $pwd)
  {//uid, firstname, lastname, password, email, role, department, employee_type, uid, id
    $this->db->where('email', $email);
    $this->db->where('password', md5($pwd));
    $query = $this->db->get('employee');
    return $query->result();
  }

  //fetch the data from notes_details and populate them in listview for userprofile_view
  public function get_all_notes()
  {
    //Call stored procedure to fetch list of all notes
    $data = $this->db->query("call Meeting_Get_All_Notes()");
    $result = $data->result();
    $data->next_result();
    $data->free_result();

    return $result;
  }

  public function get_my_notes($Userid)
  {
    $stored_procedure = "CALL Meeting_Get_My_Notes(?) ";
    $data = $this->db->query($stored_procedure,array('p_uid'=>$Userid));
    $result = $data->result();
    $data->next_result();
    $data->free_result();
    return $result;
  }

  public function get_all_employee()
  {
    $this->db->from('employee');
    $query=$this->db->get();
    return $query->result();
  }

  //function to store my notes into database
  public function insert_my_note($notesdata)
  {
    $this->db->set('Created_On', 'NOW()', FALSE);
    if ($this->db->insert("meeting_notes", $notesdata))
    {
      return true;
    }
  }
  public function get_all_project_name()
  {
    $this->db->from('projects');
    $query=$this->db->get();
    return $query->result();
  }

  //Functions related to ajax
  //
  //function to get notes by notes id
  public function get_notes_by_id($id)
  {
    $this->db->from('meeting_notes');
    $this->db->where('M_Id',$id);
    $query = $this->db->get();

    return $query->row();
  }
  //get notes by id
  public function get_notes_by_projectid($Noteid)
  {
    $stored_procedure = "CALL Meeting_Get_Notes_By_Id(?) ";
    $data = $this->db->query($stored_procedure,array('p_mid'=>$Noteid));
    $result = $data->result();
    $data->next_result();
    $data->free_result();
    return $result;
  }
  public function notes_update($where, $data)
  {
    $this->db->where('M_Id', $where);
    $this->db->update('meeting_notes', $data);
    return $this->db->affected_rows();
  }

}
?>
